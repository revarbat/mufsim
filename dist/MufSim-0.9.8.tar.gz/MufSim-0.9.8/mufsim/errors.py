class MufCompileError(Exception):
    pass


class MufRuntimeError(Exception):
    pass


class MufBreakExecution(Exception):
    pass


class ReloadAsMuvException(Exception):
    pass


# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4 nowrap
