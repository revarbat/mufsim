#!/usr/bin/env python3

from mufgui.mufgui import main


main()


# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4 nowrap
