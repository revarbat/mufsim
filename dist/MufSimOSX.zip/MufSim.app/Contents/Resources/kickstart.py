#!/usr/bin/env python3

from mufsim.gui import main


main()


# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4 nowrap
