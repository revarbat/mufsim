An offline tokenizer, interpreter, and debugger for MUF, a stack-based
forth-alike MUCK extension language.

