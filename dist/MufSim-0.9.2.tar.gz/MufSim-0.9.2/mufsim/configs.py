import os.path


EMULATED_VERSION = 'Muck2.2fb6.09'
MAX_VARS = 54
HISTORY_FILE = os.path.expanduser("~/.mufsim_history")


# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4 nowrap
